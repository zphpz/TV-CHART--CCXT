/**
 * live_trading.js — Dedicated Stationary 300s (5M) / 900s (15M) Live Trading Engine v4.2
 * 
 * Features:
 * - Dual Chart Modes:
 *   1. ₿ BTC ($) Mode: 1:1 Live Bitcoin TWAP price curve vs Strike / Target Line ($64,746 vs $64,739)
 *   2. ¢ PROB (%) Mode: Polymarket CLOB Option token probability in cents (0–100¢)
 * - 100% stationary, non-scrolling full-session canvas locked from second 0 to second 300 (or 900)
 * - Large prominent floating live head badge (20px font, 10px offset, semi-transparent glass background)
 * - Automatic historical trade backfill on mid-session join (no fake 50¢ flat line or diagonal jumps!)
 * - Real-time auto-advancing line & pulsing head from second 0 to nowSec
 * - Anti-aliased glowing live price line with gradient under-fill
 * - Pulsing live leading dot at the current active second
 * - Blue dashed vertical second & minute grid lines (+01:00, +02:00 ... / 30s, 90s ...)
 * - Dynamic price scale & horizontal reference grid (Strike line / 50¢ anchor)
 * - Interactive hover crosshair with exact price & elapsed second tooltip
 * - Single-line top header HUD with slug link, ⏳ LIVE session badge & TWAP BTC price stream
 */
'use strict';

window.LiveTradingManager = (() => {
  let _container     = null;
  let _canvas        = null;
  let _ctx           = null;
  let _tooltipEl     = null;

  let _currentMarket = null;
  let _startTs       = 0;
  let _endTs         = 0;
  let _durationSecs  = 300;     // 300 for 5M, 900 for 15M
  let _chartMode     = localStorage.getItem('pm_chart_mode') || 'btc'; // 'btc' | 'token'
  let _outcomeMode   = 'up';    // 'up' | 'down'
  
  let _rawTicks      = [];      // Array of [unixSec, rawUpCents] (0–100)
  let _btcTicks      = [];      // Array of [unixSec, btcPriceUsd]
  let _lastPrice     = null;
  let _showHeadBadge = localStorage.getItem('pm_show_head_tag') !== 'false';

  let _btcOpen       = null;
  let _btcCurrent    = null;
  let _btcChange     = null;

  let _hoverX        = null;
  let _hoverY        = null;
  let _rafId         = null;
  let _pulsePhase    = 0;

  const TOP_HUD_H    = 26;
  const RIGHT_SCALE_W= 68;
  const BOTTOM_AXIS_H= 22;

  function init(container) {
    if (!container) return false;
    _container = container;
    _container.innerHTML = '';
    _container.style.position = 'relative';
    _container.style.width = '100%';
    _container.style.height = '100%';
    _container.style.overflow = 'hidden';
    _container.style.background = '#080b0f';

    _canvas = document.createElement('canvas');
    _canvas.id = 'live-trading-canvas';
    _canvas.style.width = '100%';
    _canvas.style.height = '100%';
    _canvas.style.display = 'block';
    _canvas.style.cursor = 'crosshair';
    _container.appendChild(_canvas);
    _ctx = _canvas.getContext('2d');

    // Tooltip element
    _tooltipEl = document.createElement('div');
    _tooltipEl.id = 'live-trading-tooltip';
    _tooltipEl.style.position = 'absolute';
    _tooltipEl.style.display = 'none';
    _tooltipEl.style.pointerEvents = 'none';
    _tooltipEl.style.zIndex = '20';
    _tooltipEl.style.background = 'rgba(13, 22, 38, 0.94)';
    _tooltipEl.style.border = '1px solid #1e293b';
    _tooltipEl.style.borderRadius = '6px';
    _tooltipEl.style.padding = '4px 8px';
    _tooltipEl.style.color = '#ffffff';
    _tooltipEl.style.fontFamily = "'JetBrains Mono', monospace";
    _tooltipEl.style.fontSize = '11px';
    _tooltipEl.style.boxShadow = '0 4px 12px rgba(0,0,0,0.5)';
    _container.appendChild(_tooltipEl);

    _setupInteractions();
    _setupResize();
    _startAnimationLoop();

    console.log('[LiveTradingManager] Custom 300s/900s Live Trading Canvas initialized (v4.2)');
    return true;
  }

  // ─── Market Initialization & History Population ────────────────────
  async function setMarket(market) {
    if (!market) return;
    _currentMarket = market;
    _startTs = market.startTs || Math.floor(Date.now() / 1000);
    _endTs = market.endTs || (_startTs + 300);
    _durationSecs = Math.max(60, _endTs - _startTs);

    _rawTicks = [];
    _btcTicks = [];
    _lastPrice = null;

    _btcOpen = parseFloat(market.eventMetadata?.priceToBeat || market.eventMetadata?.targetPrice) || null;
    _btcCurrent = _btcOpen;
    _btcChange = 0;

    // Seed start anchor for BTC if available
    if (_btcOpen) {
      _btcTicks.push([_startTs, _btcOpen]);
    }

    // 1. Check if we already have ticks in local buffer
    if (window.TickBuffer) {
      const bufferTicks = window.TickBuffer.getRawTicks() || [];
      for (const t of bufferTicks) {
        if (t.time >= _startTs && t.time <= _endTs && typeof t.value === 'number') {
          _rawTicks.push([t.time, t.value]);
        }
      }
    }

    // 2. Fetch real official session price history from Polymarket APIs
    if (_rawTicks.length < 2 && window.MarketManager && market.upTokenId) {
      try {
        const hist = await MarketManager.fetchSessionPriceHistory(market.upTokenId, _startTs, _endTs);
        if (Array.isArray(hist) && hist.length > 0) {
          _rawTicks = hist;
          _lastPrice = hist[hist.length - 1][1];
          if (window.TickBuffer) {
            hist.forEach(([t, p]) => window.TickBuffer.addTick(t, p));
          }
        }
      } catch (e) {
        console.warn('[LiveTradingManager] History fetch error:', e);
      }
    }

    _render();
  }

  // ─── Real-Time Tick Ingestion ──────────────────────────────────────
  function pushTick(unixSec, rawUpCents) {
    if (typeof unixSec !== 'number' || isNaN(unixSec)) return;

    if (typeof rawUpCents !== 'number' || isNaN(rawUpCents)) {
      if (_lastPrice !== null) rawUpCents = _lastPrice;
      else return;
    }

    if (!_startTs || !_endTs) {
      _startTs = Math.floor(unixSec / 300) * 300;
      _endTs = _startTs + 300;
      _durationSecs = 300;
    }

    _lastPrice = rawUpCents;

    if (_rawTicks.length === 0) {
      _rawTicks.push([_startTs, rawUpCents]);
      if (unixSec > _startTs) {
        _rawTicks.push([unixSec, rawUpCents]);
      }
    } else {
      if (_rawTicks[_rawTicks.length - 1][0] === unixSec) {
        _rawTicks[_rawTicks.length - 1][1] = rawUpCents;
      } else {
        _rawTicks.push([unixSec, rawUpCents]);
      }
    }
  }

  function pushBtcTick(unixSec, btcPrice, strikePrice) {
    if (typeof unixSec !== 'number' || typeof btcPrice !== 'number' || isNaN(btcPrice) || btcPrice <= 0) return;

    if (strikePrice && (!_btcOpen || isNaN(_btcOpen))) {
      _btcOpen = strikePrice;
    }

    _btcCurrent = btcPrice;
    if (_btcOpen && _btcOpen > 0) {
      _btcChange = Math.round(((_btcCurrent - _btcOpen) / _btcOpen) * 10000) / 100;
    }

    if (!_startTs || !_endTs) {
      _startTs = Math.floor(unixSec / 300) * 300;
      _endTs = _startTs + 300;
      _durationSecs = 300;
    }

    if (_btcTicks.length === 0) {
      _btcTicks.push([_startTs, _btcOpen || btcPrice]);
      if (unixSec > _startTs) {
        _btcTicks.push([unixSec, btcPrice]);
      }
    } else {
      if (_btcTicks[_btcTicks.length - 1][0] === unixSec) {
        _btcTicks[_btcTicks.length - 1][1] = btcPrice;
      } else {
        _btcTicks.push([unixSec, btcPrice]);
      }
    }
  }

  function setHistoricalTicks(ticks) {
    if (Array.isArray(ticks) && ticks.length > 0) {
      _rawTicks = ticks.filter(([ts]) => ts >= _startTs && ts <= _endTs);
      if (_rawTicks.length > 0) {
        _lastPrice = _rawTicks[_rawTicks.length - 1][1];
        if (_rawTicks[0][0] > _startTs) {
          _rawTicks.unshift([_startTs, _rawTicks[0][1]]);
        }
      }
      _render();
    }
  }

  function setChartMode(mode) {
    _chartMode = mode;
    localStorage.setItem('pm_chart_mode', mode);
    _render();
  }

  function getChartMode() {
    return _chartMode;
  }

  function setOutcomeMode(mode) {
    _outcomeMode = mode;
    _render();
  }

  function setShowHeadBadge(enabled) {
    _showHeadBadge = !!enabled;
    localStorage.setItem('pm_show_head_tag', _showHeadBadge ? 'true' : 'false');
    _render();
  }

  function getShowHeadBadge() {
    return _showHeadBadge;
  }

  function updateBtcPrice(btcOpen, btcClose, btcChange) {
    if (btcOpen !== undefined && btcOpen !== null && !isNaN(btcOpen)) _btcOpen = btcOpen;
    if (btcClose !== undefined && btcClose !== null && !isNaN(btcClose)) _btcCurrent = btcClose;
    if (btcChange !== undefined && btcChange !== null && !isNaN(btcChange)) _btcChange = btcChange;

    if (_btcCurrent && _startTs) {
      const nowSec = Math.floor(Date.now() / 1000);
      pushBtcTick(nowSec, _btcCurrent, _btcOpen);
    }
  }

  // ─── Core Rendering Engine ─────────────────────────────────────────
  function _render() {
    if (!_canvas || !_ctx || !_container) return;

    const dpr = window.devicePixelRatio || 1;
    const w = _container.clientWidth;
    const h = _container.clientHeight;

    if (w <= 0 || h <= 0) return;

    if (_canvas.width !== Math.round(w * dpr) || _canvas.height !== Math.round(h * dpr)) {
      _canvas.width = Math.round(w * dpr);
      _canvas.height = Math.round(h * dpr);
    }

    _ctx.save();
    _ctx.scale(dpr, dpr);
    _ctx.clearRect(0, 0, w, h);

    const plotLeft   = 0;
    const plotTop    = TOP_HUD_H;
    const plotRight  = w - RIGHT_SCALE_W;
    const plotBottom = h - BOTTOM_AXIS_H;
    const plotW      = Math.max(10, plotRight - plotLeft);
    const plotH      = Math.max(10, plotBottom - plotTop);

    const nowSec = Math.floor(Date.now() / 1000);
    const effectiveNowSec = (_startTs && _endTs) ? Math.min(_endTs, Math.max(_startTs, nowSec)) : nowSec;
    const is5m = _durationSecs <= 300;

    // ─── 1. Vertical Blue Dashed Second Subdivision Lines ───────────
    const stepSecs = is5m ? 30 : 60;
    const majorStepSecs = is5m ? 60 : 180;

    _ctx.textAlign = 'center';
    _ctx.textBaseline = 'bottom';

    for (let s = 0; s <= _durationSecs; s += stepSecs) {
      const x = plotLeft + (s / _durationSecs) * plotW;
      const isMajor = (s % majorStepSecs === 0);

      _ctx.beginPath();
      _ctx.strokeStyle = isMajor ? 'rgba(56, 189, 248, 0.75)' : 'rgba(56, 189, 248, 0.28)';
      _ctx.lineWidth = isMajor ? 1.5 : 1;
      _ctx.setLineDash(isMajor ? [4, 4] : [2, 3]);
      _ctx.moveTo(Math.round(x) + 0.5, plotTop + 1);
      _ctx.lineTo(Math.round(x) + 0.5, plotBottom);
      _ctx.stroke();

      const m = Math.floor(s / 60);
      const secRem = s % 60;
      const fullTag = `+${String(m).padStart(2, '0')}:${String(secRem).padStart(2, '0')}`;
      const timeTag = isMajor ? `${m}m` : `${s}s`;

      _ctx.fillStyle = isMajor ? '#38bdf8' : '#64748b';
      _ctx.font = isMajor ? 'bold 10px "JetBrains Mono", monospace' : '9px "JetBrains Mono", monospace';
      _ctx.fillText(isMajor ? fullTag : timeTag, x, h - 4);
    }

    _ctx.setLineDash([]);

    // ─── MODE A: BTC PRICE ($) MODE (Polymarket 1:1 Live Chart) ──────
    if (_chartMode === 'btc') {
      let btcSessionTicks = _btcTicks.filter(([ts]) => ts >= _startTs && ts <= _endTs);

      if (btcSessionTicks.length > 0) {
        if (btcSessionTicks[0][0] > _startTs) {
          btcSessionTicks.unshift([_startTs, _btcOpen || btcSessionTicks[0][1]]);
        }
        const lastT = btcSessionTicks[btcSessionTicks.length - 1];
        if (effectiveNowSec > lastT[0]) {
          btcSessionTicks.push([effectiveNowSec, lastT[1]]);
        }
      } else if (_btcCurrent !== null) {
        btcSessionTicks.push([_startTs, _btcOpen || _btcCurrent]);
        if (effectiveNowSec > _startTs) {
          btcSessionTicks.push([effectiveNowSec, _btcCurrent]);
        }
      }

      // Calculate Y-scale bounds
      let minP = _btcOpen || (_btcCurrent || 64000);
      let maxP = _btcOpen || (_btcCurrent || 64000);

      for (const [, p] of btcSessionTicks) {
        if (p < minP) minP = p;
        if (p > maxP) maxP = p;
      }
      if (_btcCurrent) {
        if (_btcCurrent < minP) minP = _btcCurrent;
        if (_btcCurrent > maxP) maxP = _btcCurrent;
      }

      const diff = Math.max(10, (maxP - minP) * 1.35);
      const centerP = _btcOpen || ((minP + maxP) / 2);
      const yMin = Math.min(minP - 3, centerP - diff / 2);
      const yMax = Math.max(maxP + 3, centerP + diff / 2);
      const yRange = Math.max(5, yMax - yMin);

      const getY = price => plotBottom - ((price - yMin) / yRange) * plotH;

      // Draw Horizontal Grid Lines for BTC Price ($)
      _ctx.lineWidth = 1;
      _ctx.font = '10px "JetBrains Mono", monospace';
      _ctx.textAlign = 'left';
      _ctx.textBaseline = 'middle';

      const gridStep = yRange > 60 ? 10 : (yRange > 25 ? 5 : 2);
      const firstGrid = Math.ceil(yMin / gridStep) * gridStep;
      for (let p = firstGrid; p <= yMax; p += gridStep) {
        const y = getY(p);
        if (y < plotTop || y > plotBottom) continue;

        _ctx.beginPath();
        _ctx.strokeStyle = 'rgba(255, 255, 255, 0.05)';
        _ctx.moveTo(plotLeft, y);
        _ctx.lineTo(plotRight, y);
        _ctx.stroke();

        _ctx.fillStyle = '#64748b';
        _ctx.fillText(`$${p.toLocaleString('en-US', { maximumFractionDigits: 0 })}`, plotRight + 6, y);
      }

      // Draw Target Strike Line (Orange / Cyan Dashed Reference)
      if (_btcOpen) {
        const strikeY = getY(_btcOpen);
        if (strikeY >= plotTop && strikeY <= plotBottom) {
          _ctx.beginPath();
          _ctx.strokeStyle = 'rgba(245, 158, 11, 0.75)';
          _ctx.lineWidth = 1.4;
          _ctx.setLineDash([5, 4]);
          _ctx.moveTo(plotLeft, strikeY);
          _ctx.lineTo(plotRight, strikeY);
          _ctx.stroke();
          _ctx.setLineDash([]);

          _ctx.fillStyle = '#f59e0b';
          _ctx.font = 'bold 10px "JetBrains Mono", monospace';
          _roundRect(_ctx, plotRight + 2, strikeY - 8, RIGHT_SCALE_W - 4, 16, 3, true, false);
          _ctx.fillStyle = '#090d16';
          _ctx.fillText(`$${_btcOpen.toLocaleString('en-US', { minimumFractionDigits: 1, maximumFractionDigits: 1 })}`, plotRight + 4, strikeY);
        }
      }

      // Build Curve Points
      if (btcSessionTicks.length > 0) {
        const points = [];
        for (const [ts, p] of btcSessionTicks) {
          const x = plotLeft + ((ts - _startTs) / _durationSecs) * plotW;
          const y = getY(p);
          points.push({ x, y, val: p, ts });
        }

        if (points.length >= 1) {
          if (points.length === 1) {
            const extraX = Math.max(points[0].x + 1, plotLeft + ((effectiveNowSec - _startTs) / _durationSecs) * plotW);
            points.push({ x: extraX, y: points[0].y, val: points[0].val, ts: effectiveNowSec });
          }

          const latestPt = points[points.length - 1];
          const isUp = _btcOpen ? (latestPt.val >= _btcOpen) : true;
          const mainColor = isUp ? '#00d4aa' : '#ff4d6d';

          // Draw Area Fill Under Curve
          const grad = _ctx.createLinearGradient(0, plotTop, 0, plotBottom);
          grad.addColorStop(0, mainColor + '33');
          grad.addColorStop(1, mainColor + '00');

          _ctx.beginPath();
          _ctx.moveTo(points[0].x, plotBottom);
          for (let i = 0; i < points.length; i++) {
            _ctx.lineTo(points[i].x, points[i].y);
          }
          _ctx.lineTo(latestPt.x, plotBottom);
          _ctx.closePath();
          _ctx.fillStyle = grad;
          _ctx.fill();

          // Draw Glowing Price Line
          _ctx.save();
          _ctx.shadowColor = mainColor;
          _ctx.shadowBlur = 8;
          _ctx.strokeStyle = mainColor;
          _ctx.lineWidth = 2.5;
          _ctx.lineJoin = 'round';
          _ctx.lineCap = 'round';

          _ctx.beginPath();
          _ctx.moveTo(points[0].x, points[0].y);
          for (let i = 1; i < points.length; i++) {
            _ctx.lineTo(points[i].x, points[i].y);
          }
          _ctx.stroke();
          _ctx.restore();

          // Draw Pulsing Live Head Dot
          const pulseR = 4 + Math.sin(_pulsePhase) * 1.5;
          _ctx.beginPath();
          _ctx.arc(latestPt.x, latestPt.y, pulseR + 4, 0, Math.PI * 2);
          _ctx.fillStyle = mainColor + '44';
          _ctx.fill();

          _ctx.beginPath();
          _ctx.arc(latestPt.x, latestPt.y, pulseR, 0, Math.PI * 2);
          _ctx.fillStyle = mainColor;
          _ctx.fill();

          _ctx.beginPath();
          _ctx.arc(latestPt.x, latestPt.y, 2, 0, Math.PI * 2);
          _ctx.fillStyle = '#ffffff';
          _ctx.fill();

          // ─── Floating Live Head Badge in BTC Mode ─────────────────
          if (_showHeadBadge && latestPt) {
            const remSecs = Math.max(0, _endTs - effectiveNowSec);
            const remM = Math.floor(remSecs / 60);
            const remS = remSecs % 60;
            const remStr = `${String(remM).padStart(2, '0')}:${String(remS).padStart(2, '0')}`;
            
            const deltaVal = _btcOpen ? (latestPt.val - _btcOpen) : 0;
            const sign = deltaVal >= 0 ? '+$' : '-$';
            const deltaStr = `${sign}${Math.abs(deltaVal).toFixed(2)}`;
            const priceStr = `$${latestPt.val.toLocaleString('en-US', { minimumFractionDigits: 2, maximumFractionDigits: 2 })}`;
            const timerStr = `⏱ ${remStr}`;

            _ctx.save();
            _ctx.font = 'bold 16px "JetBrains Mono", monospace';
            const priceW = _ctx.measureText(priceStr).width;
            _ctx.font = 'bold 13px "JetBrains Mono", monospace';
            const deltaW = _ctx.measureText(deltaStr).width;
            const timerW = _ctx.measureText(timerStr).width;
            const gapW = 10;
            const padX = 12;
            const badgeW = Math.round(padX * 2 + priceW + gapW + deltaW + gapW + timerW);
            const badgeH = 34;
            const DOT_OFFSET = 10;

            let badgeX = Math.round(latestPt.x - badgeW / 2);
            badgeX = Math.max(plotLeft + 4, Math.min(plotRight - badgeW - 4, badgeX));

            let badgeY = Math.round(latestPt.y - badgeH - DOT_OFFSET);
            let arrowBelow = true;
            if (badgeY < plotTop + 4) {
              badgeY = Math.round(latestPt.y + DOT_OFFSET + 4);
              arrowBelow = false;
            }

            const bgSemiTransparent = 'rgba(8, 14, 24, 0.72)';

            // Draw Pointer Arrow
            _ctx.beginPath();
            if (arrowBelow) {
              _ctx.moveTo(latestPt.x - 6, badgeY + badgeH);
              _ctx.lineTo(latestPt.x, latestPt.y - 4);
              _ctx.lineTo(latestPt.x + 6, badgeY + badgeH);
            } else {
              _ctx.moveTo(latestPt.x - 6, badgeY);
              _ctx.lineTo(latestPt.x, latestPt.y + 4);
              _ctx.lineTo(latestPt.x + 6, badgeY);
            }
            _ctx.closePath();
            _ctx.fillStyle = bgSemiTransparent;
            _ctx.fill();
            _ctx.strokeStyle = mainColor + 'cc';
            _ctx.lineWidth = 1.4;
            _ctx.stroke();

            // Draw Card Body
            _ctx.shadowColor = mainColor + '88';
            _ctx.shadowBlur = 10;
            _ctx.fillStyle = bgSemiTransparent;
            _ctx.strokeStyle = mainColor + 'ee';
            _ctx.lineWidth = 1.6;
            _roundRect(_ctx, badgeX, badgeY, badgeW, badgeH, 8, true, true);
            _ctx.restore();

            // Draw Text inside Badge
            _ctx.save();
            _ctx.textBaseline = 'middle';
            const midY = badgeY + badgeH / 2;

            _ctx.textAlign = 'left';
            _ctx.font = 'bold 16px "JetBrains Mono", monospace';
            _ctx.fillStyle = '#ffffff';
            _ctx.fillText(priceStr, badgeX + padX, midY);

            _ctx.font = 'bold 14px "JetBrains Mono", monospace';
            _ctx.fillStyle = mainColor;
            _ctx.fillText(deltaStr, badgeX + padX + priceW + gapW, midY);

            _ctx.font = 'bold 13px "JetBrains Mono", monospace';
            _ctx.fillStyle = '#64748b';
            _ctx.fillText('·', badgeX + padX + priceW + gapW + deltaW + 3, midY);

            _ctx.fillStyle = remSecs <= 30 ? '#ff4d6d' : '#94a3b8';
            _ctx.fillText(timerStr, badgeX + padX + priceW + gapW + deltaW + gapW, midY);
            _ctx.restore();
          }

          // Current Price Line to Right Scale
          _ctx.beginPath();
          _ctx.strokeStyle = mainColor + '66';
          _ctx.lineWidth = 1;
          _ctx.setLineDash([3, 3]);
          _ctx.moveTo(latestPt.x, latestPt.y);
          _ctx.lineTo(plotRight, latestPt.y);
          _ctx.stroke();
          _ctx.setLineDash([]);

          // Right Scale Highlight Badge
          _ctx.fillStyle = mainColor;
          _roundRect(_ctx, plotRight + 2, latestPt.y - 9, RIGHT_SCALE_W - 4, 18, 4, true, false);
          _ctx.fillStyle = '#090d16';
          _ctx.font = 'bold 11px "JetBrains Mono", monospace';
          _ctx.textAlign = 'left';
          _ctx.textBaseline = 'middle';
          _ctx.fillText(`$${latestPt.val.toFixed(1)}`, plotRight + 4, latestPt.y);
        }
      }
    }

    // ─── MODE B: OPTION TOKEN (0–100¢) PROBABILITY MODE ──────────────
    else {
      // Draw 0¢ ... 50¢ ... 100¢ reference lines
      _ctx.lineWidth = 1;
      _ctx.font = '10px "JetBrains Mono", monospace';
      _ctx.textBaseline = 'middle';

      const priceLevels = [0, 10, 20, 30, 40, 50, 60, 70, 80, 90, 100];
      for (const p of priceLevels) {
        const y = plotBottom - (p / 100) * plotH;
        const is50 = (p === 50);
        const isBoundary = (p === 0 || p === 100);

        _ctx.beginPath();
        _ctx.strokeStyle = is50 ? 'rgba(56, 189, 248, 0.45)' : (isBoundary ? 'rgba(255,255,255,0.1)' : 'rgba(255, 255, 255, 0.04)');
        _ctx.setLineDash(is50 ? [4, 4] : []);
        _ctx.moveTo(plotLeft, y);
        _ctx.lineTo(plotRight, y);
        _ctx.stroke();

        if (p % 20 === 0 || p === 50) {
          _ctx.fillStyle = is50 ? '#38bdf8' : '#64748b';
          _ctx.fillText(`${p.toFixed(1)}¢`, plotRight + 6, y);
        }
      }

      let sessionTicks = _rawTicks.filter(([ts]) => ts >= _startTs && ts <= _endTs);

      if (sessionTicks.length > 0) {
        if (sessionTicks[0][0] > _startTs) {
          sessionTicks.unshift([_startTs, sessionTicks[0][1]]);
        }
        const lastTick = sessionTicks[sessionTicks.length - 1];
        if (effectiveNowSec > lastTick[0]) {
          sessionTicks.push([effectiveNowSec, lastTick[1]]);
        }
      } else if (_lastPrice !== null) {
        sessionTicks.push([_startTs, _lastPrice]);
        if (effectiveNowSec > _startTs) {
          sessionTicks.push([effectiveNowSec, _lastPrice]);
        }
      }

      if (sessionTicks.length > 0 && _durationSecs > 0) {
        const points = [];
        for (const [ts, upCents] of sessionTicks) {
          const val = _outcomeMode === 'down' ? (100 - upCents) : upCents;
          const x = plotLeft + ((ts - _startTs) / _durationSecs) * plotW;
          const y = plotBottom - (Math.min(100, Math.max(0, val)) / 100) * plotH;
          points.push({ x, y, val, ts });
        }

        if (points.length >= 1) {
          if (points.length === 1) {
            const extraX = Math.max(points[0].x + 1, plotLeft + ((effectiveNowSec - _startTs) / _durationSecs) * plotW);
            points.push({ x: extraX, y: points[0].y, val: points[0].val, ts: effectiveNowSec });
          }

          const latestPt = points[points.length - 1];
          const mainColor = latestPt.val > 52 ? '#00d4aa' : (latestPt.val < 48 ? '#ff4d6d' : '#38bdf8');

          const grad = _ctx.createLinearGradient(0, plotTop, 0, plotBottom);
          grad.addColorStop(0, mainColor + '33');
          grad.addColorStop(1, mainColor + '00');

          _ctx.beginPath();
          _ctx.moveTo(points[0].x, plotBottom);
          for (let i = 0; i < points.length; i++) {
            _ctx.lineTo(points[i].x, points[i].y);
          }
          _ctx.lineTo(latestPt.x, plotBottom);
          _ctx.closePath();
          _ctx.fillStyle = grad;
          _ctx.fill();

          _ctx.save();
          _ctx.shadowColor = mainColor;
          _ctx.shadowBlur = 8;
          _ctx.strokeStyle = mainColor;
          _ctx.lineWidth = 2.5;
          _ctx.lineJoin = 'round';
          _ctx.lineCap = 'round';

          _ctx.beginPath();
          _ctx.moveTo(points[0].x, points[0].y);
          for (let i = 1; i < points.length; i++) {
            _ctx.lineTo(points[i].x, points[i].y);
          }
          _ctx.stroke();
          _ctx.restore();

          const pulseR = 4 + Math.sin(_pulsePhase) * 1.5;
          _ctx.beginPath();
          _ctx.arc(latestPt.x, latestPt.y, pulseR + 4, 0, Math.PI * 2);
          _ctx.fillStyle = mainColor + '44';
          _ctx.fill();

          _ctx.beginPath();
          _ctx.arc(latestPt.x, latestPt.y, pulseR, 0, Math.PI * 2);
          _ctx.fillStyle = mainColor;
          _ctx.fill();

          _ctx.beginPath();
          _ctx.arc(latestPt.x, latestPt.y, 2, 0, Math.PI * 2);
          _ctx.fillStyle = '#ffffff';
          _ctx.fill();

          // ─── Floating Live Head Badge in Token Mode ──────────────
          if (_showHeadBadge && latestPt) {
            const remSecs = Math.max(0, _endTs - effectiveNowSec);
            const remM = Math.floor(remSecs / 60);
            const remS = remSecs % 60;
            const remStr = `${String(remM).padStart(2, '0')}:${String(remS).padStart(2, '0')}`;
            
            const priceStr = `${latestPt.val.toFixed(1)}¢`;
            const timerStr = `⏱ ${remStr}`;

            _ctx.save();
            _ctx.font = 'bold 18px "JetBrains Mono", monospace';
            const priceW = _ctx.measureText(priceStr).width;
            _ctx.font = 'bold 15px "JetBrains Mono", monospace';
            const timerW = _ctx.measureText(timerStr).width;
            const gapW = 12;
            const padX = 14;
            const badgeW = Math.round(padX * 2 + priceW + gapW + timerW);
            const badgeH = 34;
            const DOT_OFFSET = 10;

            let badgeX = Math.round(latestPt.x - badgeW / 2);
            badgeX = Math.max(plotLeft + 4, Math.min(plotRight - badgeW - 4, badgeX));

            let badgeY = Math.round(latestPt.y - badgeH - DOT_OFFSET);
            let arrowBelow = true;
            if (badgeY < plotTop + 4) {
              badgeY = Math.round(latestPt.y + DOT_OFFSET + 4);
              arrowBelow = false;
            }

            const bgSemiTransparent = 'rgba(8, 14, 24, 0.72)';

            _ctx.beginPath();
            if (arrowBelow) {
              _ctx.moveTo(latestPt.x - 6, badgeY + badgeH);
              _ctx.lineTo(latestPt.x, latestPt.y - 4);
              _ctx.lineTo(latestPt.x + 6, badgeY + badgeH);
            } else {
              _ctx.moveTo(latestPt.x - 6, badgeY);
              _ctx.lineTo(latestPt.x, latestPt.y + 4);
              _ctx.lineTo(latestPt.x + 6, badgeY);
            }
            _ctx.closePath();
            _ctx.fillStyle = bgSemiTransparent;
            _ctx.fill();
            _ctx.strokeStyle = mainColor + 'cc';
            _ctx.lineWidth = 1.4;
            _ctx.stroke();

            _ctx.shadowColor = mainColor + '88';
            _ctx.shadowBlur = 10;
            _ctx.fillStyle = bgSemiTransparent;
            _ctx.strokeStyle = mainColor + 'ee';
            _ctx.lineWidth = 1.6;
            _roundRect(_ctx, badgeX, badgeY, badgeW, badgeH, 8, true, true);
            _ctx.restore();

            _ctx.save();
            _ctx.textBaseline = 'middle';
            const midY = badgeY + badgeH / 2;

            _ctx.textAlign = 'left';
            _ctx.font = 'bold 18px "JetBrains Mono", monospace';
            _ctx.fillStyle = mainColor;
            _ctx.fillText(priceStr, badgeX + padX, midY);

            _ctx.font = 'bold 15px "JetBrains Mono", monospace';
            _ctx.fillStyle = '#64748b';
            _ctx.fillText('·', badgeX + padX + priceW + 4, midY);

            _ctx.fillStyle = remSecs <= 30 ? '#ff4d6d' : '#ffffff';
            _ctx.fillText(timerStr, badgeX + padX + priceW + gapW, midY);
            _ctx.restore();
          }

          _ctx.beginPath();
          _ctx.strokeStyle = mainColor + '66';
          _ctx.lineWidth = 1;
          _ctx.setLineDash([3, 3]);
          _ctx.moveTo(latestPt.x, latestPt.y);
          _ctx.lineTo(plotRight, latestPt.y);
          _ctx.stroke();
          _ctx.setLineDash([]);

          _ctx.fillStyle = mainColor;
          _roundRect(_ctx, plotRight + 2, latestPt.y - 9, RIGHT_SCALE_W - 4, 18, 4, true, false);
          _ctx.fillStyle = '#090d16';
          _ctx.font = 'bold 11px "JetBrains Mono", monospace';
          _ctx.textAlign = 'left';
          _ctx.textBaseline = 'middle';
          _ctx.fillText(`${latestPt.val.toFixed(1)}¢`, plotRight + 6, latestPt.y);
        }
      }
    }

    // ─── 4. Top Slim Header HUD ───────────────────────────────────────
    _ctx.fillStyle = 'rgba(9, 17, 30, 0.92)';
    _ctx.fillRect(0, 0, w, TOP_HUD_H);

    _ctx.strokeStyle = 'rgba(56, 189, 248, 0.35)';
    _ctx.lineWidth = 1;
    _ctx.beginPath();
    _ctx.moveTo(0, TOP_HUD_H + 0.5);
    _ctx.lineTo(w, TOP_HUD_H + 0.5);
    _ctx.stroke();

    const fullSlug = _currentMarket?.slug || 'Live Session';
    const isMobile = (w < 600);
    const slugText = isMobile ? `...${fullSlug.slice(-10)} ↗` : `${fullSlug} ↗`;
    const labelDuration = isMobile ? (is5m ? '5M' : '15M') : (is5m ? '5M FIXED (300s)' : '15M FIXED (900s)');
    const modeBadge = _chartMode === 'btc' ? '₿ BTC ($)' : '¢ PROB (%)';

    let curX = isMobile ? 8 : 14;
    const textY = 17;

    _ctx.textAlign = 'left';
    _ctx.textBaseline = 'alphabetic';

    _ctx.font = isMobile ? '600 11px "JetBrains Mono", monospace' : '600 12px "JetBrains Mono", monospace';
    _ctx.fillStyle = '#ffffff';
    _ctx.fillText(slugText, curX, textY);
    curX += _ctx.measureText(slugText).width + (isMobile ? 6 : 10);

    _ctx.fillStyle = '#64748b';
    _ctx.fillText('·', curX, textY);
    curX += isMobile ? 10 : 14;

    _ctx.fillStyle = '#38bdf8';
    _ctx.font = isMobile ? '800 11px "JetBrains Mono", monospace' : '800 12px "JetBrains Mono", monospace';
    _ctx.fillText(`⏳ ${labelDuration}`, curX, textY);
    curX += _ctx.measureText(`⏳ ${labelDuration}`).width + (isMobile ? 6 : 10);

    _ctx.fillStyle = '#64748b';
    _ctx.fillText('·', curX, textY);
    curX += isMobile ? 10 : 14;

    _ctx.fillStyle = '#a855f7';
    _ctx.font = isMobile ? '700 10px "JetBrains Mono", monospace' : '700 11px "JetBrains Mono", monospace';
    _ctx.fillText(modeBadge, curX, textY);
    curX += _ctx.measureText(modeBadge).width + (isMobile ? 6 : 10);

    // TWAP BTC Price Feed
    if (_btcCurrent && curX + 110 < w - RIGHT_SCALE_W) {
      _ctx.fillStyle = '#64748b';
      _ctx.fillText('·', curX, textY);
      curX += isMobile ? 10 : 14;

      const sign = (_btcChange || 0) >= 0 ? '+' : '';
      const chgStr = _btcChange !== null && _btcChange !== undefined ? ` (${sign}${_btcChange.toFixed(2)}%)` : '';

      _ctx.fillStyle = '#94a3b8';
      _ctx.font = isMobile ? '600 11px "JetBrains Mono", monospace' : '600 12px "JetBrains Mono", monospace';
      _ctx.fillText('TWAP ', curX, textY);
      curX += _ctx.measureText('TWAP ').width;

      let priceText = '';
      if (isMobile) {
        priceText = `$${_btcCurrent.toLocaleString('en-US', { minimumFractionDigits: 1, maximumFractionDigits: 1 })}${chgStr}`;
      } else {
        const openStr = _btcOpen ? '$' + _btcOpen.toLocaleString('en-US', { minimumFractionDigits: 2, maximumFractionDigits: 2 }) : '--';
        const curStr  = '$' + _btcCurrent.toLocaleString('en-US', { minimumFractionDigits: 2, maximumFractionDigits: 2 });
        priceText = `${openStr} → ${curStr}${chgStr}`;
      }

      _ctx.fillStyle = (_btcChange || 0) >= 0 ? '#34d399' : '#cbd5e1';
      _ctx.fillText(priceText, curX, textY, (w - RIGHT_SCALE_W - curX - 6));
    }

    _ctx.restore();
  }

  function _roundRect(ctx, x, y, width, height, radius, fill, stroke) {
    ctx.beginPath();
    ctx.moveTo(x + radius, y);
    ctx.lineTo(x + width - radius, y);
    ctx.quadraticCurveTo(x + width, y, x + width, y + radius);
    ctx.lineTo(x + width, y + height - radius);
    ctx.quadraticCurveTo(x + width, y + height, x + width - radius, y + height);
    ctx.lineTo(x + radius, y + height);
    ctx.quadraticCurveTo(x, y + height, x, y + height - radius);
    ctx.lineTo(x, y + radius);
    ctx.quadraticCurveTo(x, y, x + radius, y);
    ctx.closePath();
    if (fill) ctx.fill();
    if (stroke) ctx.stroke();
  }

  function _startAnimationLoop() {
    function loop() {
      _pulsePhase += 0.08;
      _render();
      _rafId = requestAnimationFrame(loop);
    }
    _rafId = requestAnimationFrame(loop);
  }

  function _setupInteractions() {
    if (!_canvas) return;

    _canvas.addEventListener('mousemove', (e) => {
      const rect = _canvas.getBoundingClientRect();
      _hoverX = e.clientX - rect.left;
      _hoverY = e.clientY - rect.top;

      if (_hoverY <= TOP_HUD_H) {
        _canvas.style.cursor = 'pointer';
      } else {
        _canvas.style.cursor = 'crosshair';
      }
    });

    _canvas.addEventListener('mouseleave', () => {
      _hoverX = null;
      _hoverY = null;
      if (_tooltipEl) _tooltipEl.style.display = 'none';
    });

    _canvas.addEventListener('touchstart', (e) => {
      if (e.touches.length > 0) {
        const rect = _canvas.getBoundingClientRect();
        _hoverX = e.touches[0].clientX - rect.left;
        _hoverY = e.touches[0].clientY - rect.top;
      }
    }, { passive: true });

    _canvas.addEventListener('touchmove', (e) => {
      if (e.touches.length > 0) {
        const rect = _canvas.getBoundingClientRect();
        _hoverX = e.touches[0].clientX - rect.left;
        _hoverY = e.touches[0].clientY - rect.top;
      }
    }, { passive: true });

    _canvas.addEventListener('touchend', () => {
      setTimeout(() => {
        _hoverX = null;
        _hoverY = null;
        if (_tooltipEl) _tooltipEl.style.display = 'none';
      }, 3000);
    });

    _canvas.addEventListener('click', (e) => {
      const rect = _canvas.getBoundingClientRect();
      const my = e.clientY - rect.top;
      if (my <= TOP_HUD_H && _currentMarket?.slug) {
        window.open(`https://polymarket.com/event/${_currentMarket.slug}`, '_blank');
      }
    });
  }

  function _setupResize() {
    if (!_container) return;
    const ro = new ResizeObserver(() => {
      _render();
    });
    ro.observe(_container);
  }

  function resize() {
    _render();
  }

  function destroy() {
    if (_rafId) cancelAnimationFrame(_rafId);
  }

  return {
    init,
    setMarket,
    pushTick,
    pushBtcTick,
    setHistoricalTicks,
    setChartMode,
    getChartMode,
    setOutcomeMode,
    setShowHeadBadge,
    getShowHeadBadge,
    updateBtcPrice,
    resize,
    destroy,
  };
})();
